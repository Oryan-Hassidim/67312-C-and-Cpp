#!/bin/bash

./school 1
./school 2
./school 3
./school 4
./school 5
./school 6
./school 7
./school 8
./school 9
./school 10
./school 11
./school 12
./school 13
./school 14
./school 15
./school 16
./school 17
./school 18
./school 19
./school 20
./school 21
./school 22
./school 23
./school 24
./school 25
./school 26
